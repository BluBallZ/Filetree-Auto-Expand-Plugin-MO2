from .expand_filetree import ExpandFileTree

def createPlugins():
    return [ExpandFileTree()]